# VisionAid
Web Application for Enhanced Accessibility for the Blind
